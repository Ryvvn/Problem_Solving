using System;
using System.Collections.Generic;
using UnityEngine;

namespace CMProblemSolving.L1901_ScenarioDone {

    public class QuestSystem : MonoBehaviour {



    }


}