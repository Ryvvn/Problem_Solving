using TMPro;
using UnityEngine;

namespace CMProblemSolving.L1901_ScenarioDone {

    public class NPC : MonoBehaviour, IInteractable {


        [SerializeField] private TextMeshPro textMesh;



        public void Interact() {
        }


    }

}