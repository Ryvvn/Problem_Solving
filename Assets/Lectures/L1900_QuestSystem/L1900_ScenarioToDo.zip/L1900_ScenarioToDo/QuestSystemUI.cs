using TMPro;
using UnityEngine;

namespace CMProblemSolving.L1901_ScenarioDone {

    public class QuestSystemUI : MonoBehaviour {


        [SerializeField] private Transform template;
        [SerializeField] private Transform container;


        private void Awake() {
            template.gameObject.SetActive(false);
        }

    }


}