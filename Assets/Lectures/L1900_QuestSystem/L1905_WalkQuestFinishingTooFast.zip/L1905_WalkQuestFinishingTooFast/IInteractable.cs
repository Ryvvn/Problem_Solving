using UnityEngine;

namespace CMProblemSolving.L1905_WalkQuestFinishingTooFast {

    public interface IInteractable {

        public void Interact();

    }

}