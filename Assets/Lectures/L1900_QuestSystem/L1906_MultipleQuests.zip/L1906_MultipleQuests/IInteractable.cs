using UnityEngine;

namespace CMProblemSolving.L1902_AAAAAAAAA {

    public interface IInteractable {

        public void Interact();

    }

}