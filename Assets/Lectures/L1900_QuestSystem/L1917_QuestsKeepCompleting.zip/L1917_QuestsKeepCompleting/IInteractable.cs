using UnityEngine;

namespace CMProblemSolving.L1917_QuestsKeepCompleting {

    public interface IInteractable {

        public void Interact();

    }

}