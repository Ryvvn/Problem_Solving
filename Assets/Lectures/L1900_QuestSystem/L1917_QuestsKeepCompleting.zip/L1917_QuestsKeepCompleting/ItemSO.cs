using System;
using UnityEngine;

namespace CMProblemSolving.L1917_QuestsKeepCompleting {

    [CreateAssetMenu(menuName = "CodeMonkey/L1902_AAAAAAAAAA/ItemSO")]
    public class ItemSO : ScriptableObject {

        public Sprite sprite;

    }

}