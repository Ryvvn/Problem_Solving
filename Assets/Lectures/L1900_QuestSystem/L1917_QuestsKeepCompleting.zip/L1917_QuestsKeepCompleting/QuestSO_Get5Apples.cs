using System;
using UnityEngine;

namespace CMProblemSolving.L1917_QuestsKeepCompleting {

    [CreateAssetMenu(menuName = "CodeMonkey/L1902_AAAAAAAAA/QuestSO_Get5Apples")]
    public class QuestSO_Get5Apples : QuestSO {

        
        
        public ItemSO itemSO;



        public override void StartQuest() {
            InventorySystem inventorySystem = PlayerPickup.Instance.GetInventorySystem();

            EventHandler onItemSOListChanged = null;

            onItemSOListChanged = (object sender, EventArgs e) => {
                if (inventorySystem.GetItemAmount(itemSO) >= 5) {
                    QuestSystem.Instance.CompleteQuest(this);
                }
                QuestSystem.Instance.TriggerOnQuestProgressChanged();
            };

            inventorySystem.OnItemSOListChanged += onItemSOListChanged;
        }

        public override float GetProgress() {
            InventorySystem inventorySystem = PlayerPickup.Instance.GetInventorySystem();
            return inventorySystem.GetItemAmount(itemSO) / 5f;
        }

    }

}