using System;
using System.Collections.Generic;
using UnityEngine;

namespace CMProblemSolving.L1917_QuestsKeepCompleting {

    public class QuestSystem : MonoBehaviour {


        public static QuestSystem Instance { get; private set; }



        public event EventHandler OnQuestListChanged;
        public event EventHandler OnQuestProgressChanged;


        [SerializeField] private Transform questCompletedDisplay;


        private List<QuestSO> questList = new List<QuestSO>();


        private void Awake() {
            Instance = this;
        }

        public bool HasQuest(QuestSO questSO) {
            return questList.Contains(questSO);
        }

        public void AddQuest(QuestSO questSO) {
            questList.Add(questSO);

            questSO.StartQuest();

            OnQuestListChanged?.Invoke(this, EventArgs.Empty);
        }

        public void CompleteQuest(QuestSO questSO) {
            questList.Remove(questSO);

            Instantiate(questCompletedDisplay, PlayerInteractionSystem.Instance.transform.position, Quaternion.identity);

            OnQuestListChanged?.Invoke(this, EventArgs.Empty);
        }

        public List<QuestSO> GetQuestList() {
            return questList;
        }

        public void TriggerOnQuestProgressChanged() {
            OnQuestProgressChanged?.Invoke(this, EventArgs.Empty);
        }

    }


}