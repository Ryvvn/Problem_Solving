using UnityEngine;

namespace CMProblemSolving.L1917_QuestsKeepCompleting {

    public class QuestCompletedDisplay : MonoBehaviour {


        private float timer = 1f;


        private void Update() {
            transform.position += Vector3.up * Time.deltaTime;
            timer -= Time.deltaTime;
            if (timer <= 0f) {
                Destroy(gameObject);
            }
        }
    }

}