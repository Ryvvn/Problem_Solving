using UnityEngine;

namespace CMProblemSolving.L1907_NotPickingUpQuests {

    public interface IInteractable {

        public void Interact();

    }

}