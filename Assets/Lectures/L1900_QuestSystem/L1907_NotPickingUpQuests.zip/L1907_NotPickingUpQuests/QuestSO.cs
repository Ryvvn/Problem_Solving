using System;
using UnityEngine;

namespace CMProblemSolving.L1907_NotPickingUpQuests {

    public abstract class QuestSO : ScriptableObject {


        public string questTitle;


        public abstract void StartQuest();

        public abstract float GetProgress();
 

    }

}