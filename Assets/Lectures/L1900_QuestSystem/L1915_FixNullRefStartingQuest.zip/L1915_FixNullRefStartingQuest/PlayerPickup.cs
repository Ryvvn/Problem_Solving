using UnityEngine;
using UnityEngine.InputSystem;

namespace CMProblemSolving.L1915_FixNullRefStartingQuest {


    public class PlayerPickup : MonoBehaviour {


        public static PlayerPickup Instance { get; private set; }



        private InventorySystem inventorySystem;


        private void Awake() {
            Instance = this;

            inventorySystem = GetComponent<InventorySystem>();
        }

        private void OnTriggerEnter2D(Collider2D collider2D) {
            if (collider2D.TryGetComponent(out ItemHolder itemHolder)) {
                inventorySystem.AddItem(itemHolder.GetItemSO());
                itemHolder.DestroySelf();
            }
        }

        public InventorySystem GetInventorySystem() {
            return inventorySystem;
        }

    }


}