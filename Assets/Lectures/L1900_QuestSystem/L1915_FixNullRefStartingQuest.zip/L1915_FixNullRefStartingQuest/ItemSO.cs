using System;
using UnityEngine;

namespace CMProblemSolving.L1915_FixNullRefStartingQuest {

    [CreateAssetMenu(menuName = "CodeMonkey/L1902_AAAAAAAAAA/ItemSO")]
    public class ItemSO : ScriptableObject {

        public Sprite sprite;

    }

}