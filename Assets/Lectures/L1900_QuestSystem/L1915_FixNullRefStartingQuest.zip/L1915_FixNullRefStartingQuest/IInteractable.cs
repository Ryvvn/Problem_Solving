using UnityEngine;

namespace CMProblemSolving.L1915_FixNullRefStartingQuest {

    public interface IInteractable {

        public void Interact();

    }

}