using UnityEngine;

namespace CMProblemSolving.L1914_StartsWithOneQuest {

    public interface IInteractable {

        public void Interact();

    }

}