using UnityEngine;

namespace CMProblemSolving.L1909_QuestsNotCompleting {

    public interface IInteractable {

        public void Interact();

    }

}