using UnityEngine;

namespace CMProblemSolving.L1904_WalkQuestNotWorking {

    public interface IInteractable {

        public void Interact();

    }

}