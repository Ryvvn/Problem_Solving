using UnityEngine;

namespace CMProblemSolving.L1901_ScenarioDone {

    public interface IInteractable {

        public void Interact();

    }

}