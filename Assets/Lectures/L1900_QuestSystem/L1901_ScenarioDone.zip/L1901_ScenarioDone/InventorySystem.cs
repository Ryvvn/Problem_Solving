using System;
using System.Collections.Generic;
using UnityEngine;

namespace CMProblemSolving.L1901_ScenarioDone {

    public class InventorySystem : MonoBehaviour {



        public event EventHandler OnItemSOListChanged;


        [SerializeField] private List<ItemSO> itemSOList;


        public void AddItem(ItemSO itemSO) {
            itemSOList.Add(itemSO);
            OnItemSOListChanged?.Invoke(this, EventArgs.Empty);
        }

        public ItemSO RemoveItem() {
            if (itemSOList.Count == 0) {
                return null;
            } else {
                ItemSO itemSO = itemSOList[itemSOList.Count - 1];
                itemSOList.RemoveAt(itemSOList.Count - 1);
                OnItemSOListChanged?.Invoke(this, EventArgs.Empty);
                return itemSO;
            }
        }

        public bool HasItem(ItemSO itemSO) {
            return itemSOList.Contains(itemSO);
        }

        public int GetItemAmount(ItemSO testItemSO) {
            int amount = 0;
            foreach (ItemSO itemSO in itemSOList) {
                if (itemSO == testItemSO) {
                    amount++;
                }
            }
            return amount;
        }

        public List<ItemSO> GetItemSOList() {
            return itemSOList;
        }

    }

}