using System;
using UnityEngine;

namespace CMProblemSolving.L1911_CannotStartQuests2 {

    public abstract class QuestSO : ScriptableObject {


        public string questTitle;


        public abstract void StartQuest();

        public abstract float GetProgress();
 

    }

}