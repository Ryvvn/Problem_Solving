using UnityEngine;

namespace CMProblemSolving.L1911_CannotStartQuests2 {

    public interface IInteractable {

        public void Interact();

    }

}