using TMPro;
using UnityEngine;

namespace CMProblemSolving.L1911_CannotStartQuests2 {

    public class NPC : MonoBehaviour, IInteractable {


        [SerializeField] private QuestSO questSO;
        [SerializeField] private TextMeshPro textMesh;


        private bool hasPickedUpQuest;
        

        private void QuestSystem_OnQuestListChanged(object sender, System.EventArgs e) {
            if (QuestSystem.Instance.HasQuest(questSO)) {
                textMesh.text = "?";
            } else {
                if (!hasPickedUpQuest) {
                    textMesh.text = "!";
                } else {
                    textMesh.text = "";
                }
            }
        }

        public void Interact() {
            if (!QuestSystem.Instance.HasQuest(questSO) && !hasPickedUpQuest) {
                QuestSystem.Instance.AddQuest(questSO);
                hasPickedUpQuest = true;
            }
        }


    }

}