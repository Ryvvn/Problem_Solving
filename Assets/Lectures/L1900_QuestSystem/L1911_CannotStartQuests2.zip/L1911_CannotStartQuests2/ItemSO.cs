using System;
using UnityEngine;

namespace CMProblemSolving.L1911_CannotStartQuests2 {

    [CreateAssetMenu(menuName = "CodeMonkey/L1902_AAAAAAAAAA/ItemSO")]
    public class ItemSO : ScriptableObject {

        public Sprite sprite;

    }

}