using System;
using UnityEngine;

namespace CMProblemSolving.L1910_CannotStartQuests {

    [CreateAssetMenu(menuName = "CodeMonkey/L1902_AAAAAAAAAA/ItemSO")]
    public class ItemSO : ScriptableObject {

        public Sprite sprite;

    }

}