using UnityEngine;

namespace CMProblemSolving.L1910_CannotStartQuests {

    public interface IInteractable {

        public void Interact();

    }

}