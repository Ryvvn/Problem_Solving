using UnityEngine;

namespace CMProblemSolving.L1918_ApplesQuestNotProgressing {

    public interface IInteractable {

        public void Interact();

    }

}