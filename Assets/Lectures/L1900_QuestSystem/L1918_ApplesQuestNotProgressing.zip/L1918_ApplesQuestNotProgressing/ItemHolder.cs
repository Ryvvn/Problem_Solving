using UnityEngine;

namespace CMProblemSolving.L1918_ApplesQuestNotProgressing {

    public class ItemHolder : MonoBehaviour {


        [SerializeField] private ItemSO itemSO;
        [SerializeField] private SpriteRenderer spriteRenderer;


        public void SetItemSO(ItemSO itemSO) {
            this.itemSO = itemSO;
            spriteRenderer.sprite = itemSO.sprite;
        }

        public ItemSO GetItemSO() {
            return itemSO;
        }

        public void DestroySelf() {
            Destroy(gameObject);
        }

    }

}