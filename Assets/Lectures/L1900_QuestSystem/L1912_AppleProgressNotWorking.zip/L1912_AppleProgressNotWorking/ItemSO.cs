using System;
using UnityEngine;

namespace CMProblemSolving.L1912_AppleProgressNotWorking {

    [CreateAssetMenu(menuName = "CodeMonkey/L1902_AAAAAAAAAA/ItemSO")]
    public class ItemSO : ScriptableObject {

        public Sprite sprite;

    }

}