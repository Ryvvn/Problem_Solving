using UnityEngine;

namespace CMProblemSolving.L1912_AppleProgressNotWorking {

    public class ItemHolder : MonoBehaviour {


        [SerializeField] private ItemSO itemSO;
        [SerializeField] private SpriteRenderer spriteRenderer;


        private void Start() {
            spriteRenderer.sprite = itemSO.sprite;
        }

        public void SetItemSO(ItemSO itemSO) {
            this.itemSO = itemSO;
            spriteRenderer.sprite = itemSO.sprite;
        }

        public ItemSO GetItemSO() {
            return itemSO;
        }

        public void DestroySelf() {
            Destroy(gameObject);
        }

    }

}