using UnityEngine;

namespace CMProblemSolving.L1912_AppleProgressNotWorking {

    public interface IInteractable {

        public void Interact();

    }

}