using UnityEngine;

namespace CMProblemSolving.L1902_StartingQuestError {

    public interface IInteractable {

        public void Interact();

    }

}