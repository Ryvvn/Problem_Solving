using TMPro;
using UnityEngine;

namespace CMProblemSolving.L1903_QuestsDoNotProgress {

    public class QuestSystemUI : MonoBehaviour {


        [SerializeField] private Transform template;
        [SerializeField] private Transform container;


        private void Awake() {
            template.gameObject.SetActive(false);
        }

        private void Start() {
            QuestSystem.Instance.OnQuestListChanged += QuestSystem_OnQuestListChanged;
            QuestSystem.Instance.OnQuestProgressChanged += QuestSystem_OnQuestProgressChanged;

            UpdateQuestList();
        }

        private void QuestSystem_OnQuestProgressChanged(object sender, System.EventArgs e) {
            UpdateQuestList();
        }

        private void QuestSystem_OnQuestListChanged(object sender, System.EventArgs e) {
            UpdateQuestList();
        }

        private void UpdateQuestList() {
            foreach (Transform child in container) {
                if (child == template) {
                    continue;
                }
                Destroy(child.gameObject);
            }

            foreach (QuestSO questSO in QuestSystem.Instance.GetQuestList()) {
                Transform questTransform = Instantiate(template, container);

                questTransform.gameObject.SetActive(true);
                questTransform.Find("Text").GetComponent<TextMeshProUGUI>().text = "<color=#ffff00>?</color> " + questSO.questTitle 
                    + "(" + Mathf.Round(questSO.GetProgress() * 100f) + "%)";
            }
        }

    }


}