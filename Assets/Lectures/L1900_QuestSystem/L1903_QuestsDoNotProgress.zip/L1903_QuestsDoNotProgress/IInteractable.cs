using UnityEngine;

namespace CMProblemSolving.L1903_QuestsDoNotProgress {

    public interface IInteractable {

        public void Interact();

    }

}