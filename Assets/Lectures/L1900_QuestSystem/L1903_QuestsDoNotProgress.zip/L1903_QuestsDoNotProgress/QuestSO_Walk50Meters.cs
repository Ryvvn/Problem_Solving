using System;
using UnityEngine;

namespace CMProblemSolving.L1903_QuestsDoNotProgress {

    [CreateAssetMenu(menuName = "CodeMonkey/L1902_AAAAAAAAA/QuestSO_Walk50Meters")]
    public class QuestSO_Walk50Meters : QuestSO {



        private float moveAmount;
        private float moveAmountMax = 50;


        public override void StartQuest() {
            EventHandler onUpdate = null;

            moveAmount = 0f;
            Vector3 lastPosition = PlayerInteractionSystem.Instance.transform.position;

            onUpdate = (object sender, EventArgs e) => {
                Vector3 moveDelta = PlayerInteractionSystem.Instance.transform.position - lastPosition;
                float fasterMovementMultiplier = 3f;
                moveAmount += moveDelta.magnitude * fasterMovementMultiplier;
                lastPosition = PlayerInteractionSystem.Instance.transform.position;

                if (moveDelta.magnitude != 0) {
                    QuestSystem.Instance.TriggerOnQuestProgressChanged();
                }

                if (moveAmount >= moveAmountMax) {
                    QuestSystem.Instance.CompleteQuest(this);
                    PlayerInteractionSystem.Instance.OnUpdate -= onUpdate;
                }
            };

            PlayerInteractionSystem.Instance.OnUpdate += onUpdate;
        }

        public override float GetProgress() {
            return moveAmount / moveAmountMax;
        }

    }

}