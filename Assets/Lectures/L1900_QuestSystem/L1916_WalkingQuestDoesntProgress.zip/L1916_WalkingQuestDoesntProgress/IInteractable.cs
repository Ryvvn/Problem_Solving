using UnityEngine;

namespace CMProblemSolving.L1916_WalkingQuestDoesntProgress {

    public interface IInteractable {

        public void Interact();

    }

}