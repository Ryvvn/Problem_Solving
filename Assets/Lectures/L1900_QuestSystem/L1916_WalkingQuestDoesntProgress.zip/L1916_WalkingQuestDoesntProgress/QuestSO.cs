using System;
using UnityEngine;

namespace CMProblemSolving.L1916_WalkingQuestDoesntProgress {

    public abstract class QuestSO : ScriptableObject {


        public string questTitle;


        public abstract void StartQuest();

        public abstract float GetProgress();
 

    }

}