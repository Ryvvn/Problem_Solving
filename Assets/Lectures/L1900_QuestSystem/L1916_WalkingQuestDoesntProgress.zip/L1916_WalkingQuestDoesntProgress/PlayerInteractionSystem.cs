using System;
using UnityEngine;
using UnityEngine.InputSystem;

namespace CMProblemSolving.L1916_WalkingQuestDoesntProgress {

    public class PlayerInteractionSystem : MonoBehaviour {


        public static PlayerInteractionSystem Instance { get; private set; }


        public event EventHandler OnUpdate;


        [SerializeField] private GameObject interactDisplay;


        private void Awake() {
            Instance = this;

            interactDisplay.SetActive(false);
        }

        private void Update() {
            float interactRadius = 1f;
            Collider2D[] collider2DArray = Physics2D.OverlapCircleAll(transform.position, interactRadius);
            IInteractable interactable = null;
            foreach (Collider2D collider2D in collider2DArray) {
                if (collider2D.TryGetComponent(out interactable)) {
                    break;
                }
            }

            interactDisplay.SetActive(interactable != null);

            if (Keyboard.current.eKey.wasPressedThisFrame) {
                if (interactable != null) {
                    interactable.Interact();
                }
            }

            OnUpdate?.Invoke(this, EventArgs.Empty);
        }



    }

}