using System;
using UnityEngine;

namespace CMProblemSolving.L1901_QuestSystem {

    [CreateAssetMenu(menuName = "CodeMonkey/L1901_QuestSystem/ItemSO")]
    public class ItemSO : ScriptableObject {

        public Sprite sprite;

    }

}