using TMPro;
using UnityEngine;

namespace CMProblemSolving.L1901_QuestSystem {

    public class NPC : MonoBehaviour, IInteractable {


        [SerializeField] private QuestSO questSO;
        [SerializeField] private TextMeshPro textMesh;


        private bool hasPickedUpQuest;


        private void Start() {
            QuestSystem.Instance.OnQuestListChanged += QuestSystem_OnQuestListChanged;
        }

        private void QuestSystem_OnQuestListChanged(object sender, System.EventArgs e) {
            if (QuestSystem.Instance.HasQuest(questSO)) {
                textMesh.text = "?";
            } else {
                if (!hasPickedUpQuest) {
                    textMesh.text = "!";
                } else {
                    textMesh.text = "";
                }
            }
        }

        public void Interact() {
            if (!QuestSystem.Instance.HasQuest(questSO) && !hasPickedUpQuest) {
                QuestSystem.Instance.AddQuest(questSO);
                hasPickedUpQuest = true;
            }
        }


    }

}