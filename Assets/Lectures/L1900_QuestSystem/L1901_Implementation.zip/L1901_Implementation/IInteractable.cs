using UnityEngine;

namespace CMProblemSolving.L1901_QuestSystem {

    public interface IInteractable {

        public void Interact();

    }

}