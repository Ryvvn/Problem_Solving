using System;
using UnityEngine;

namespace CMProblemSolving.L1901_QuestSystem {

    public abstract class QuestSO : ScriptableObject {


        public string questTitle;


        public abstract void StartQuest();

        public abstract float GetProgress();
 

    }

}