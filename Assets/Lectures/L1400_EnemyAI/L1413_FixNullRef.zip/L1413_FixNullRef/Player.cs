using UnityEngine;

namespace CMProblemSolving.L1413_FixNullRef {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }




    }

}