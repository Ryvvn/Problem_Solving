using UnityEngine;

namespace CMProblemSolving.L1402_AttacksTooFar {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}