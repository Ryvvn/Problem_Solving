using UnityEngine;

namespace CMProblemSolving.L1407_ShootingIncorrectly {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}