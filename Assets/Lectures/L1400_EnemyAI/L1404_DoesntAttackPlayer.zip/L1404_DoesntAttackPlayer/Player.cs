using UnityEngine;

namespace CMProblemSolving.L1404_DoesntAttackPlayer {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}