using UnityEngine;

namespace CMProblemSolving.L1406_PlayerDyingOneShot {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}