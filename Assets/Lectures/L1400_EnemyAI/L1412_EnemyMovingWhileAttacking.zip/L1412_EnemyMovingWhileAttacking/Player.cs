using UnityEngine;

namespace CMProblemSolving.L1412_EnemyMovingWhileAttacking {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}