using UnityEngine;

namespace CMProblemSolving.L1415_AttackingTooFar {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}