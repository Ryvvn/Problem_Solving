using UnityEngine;

namespace CMProblemSolving.L1414_EnemyShootsFarTarget {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        [SerializeField] private bool isInstance;


        private void Awake() {
            if (isInstance) {
                Instance = this;
            }
        }


    }

}