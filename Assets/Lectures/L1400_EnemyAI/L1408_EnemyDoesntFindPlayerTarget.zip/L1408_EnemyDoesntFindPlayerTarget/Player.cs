using UnityEngine;

namespace CMProblemSolving.L1408_EnemyDoesntFindPlayerTarget {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}