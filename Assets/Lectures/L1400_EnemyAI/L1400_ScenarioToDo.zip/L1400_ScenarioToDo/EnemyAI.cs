using UnityEngine;

namespace CMProblemSolving.L1401_ScenarioDone {

    public class EnemyAI : MonoBehaviour {



        [SerializeField] private Bullet bulletPrefab;
        [SerializeField] private Transform pistolTransform;
        [SerializeField] private Transform pistolShootPointTransform;

        private float moveSpeed = 1.0f;


        private void Update() {
            /*
            switch (state) {
                case State.LookingForTarget:
                    break;
            }
            */
        }

        private void MoveLeft() {
            transform.position += Vector3.left * moveSpeed * Time.deltaTime;
        }

        private void AimPistolAtPlayer() {
            Vector3 aimDirection = (Player.Instance.transform.position - transform.position).normalized;
            pistolTransform.right = aimDirection;
        }

        private void ShootBulletAtPlayer() {
            AimPistolAtPlayer();

            Bullet bullet = Instantiate(bulletPrefab, pistolShootPointTransform.position, pistolShootPointTransform.rotation);
        }


    }

}