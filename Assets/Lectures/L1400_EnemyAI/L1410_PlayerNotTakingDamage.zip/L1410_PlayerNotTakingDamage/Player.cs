using UnityEngine;

namespace CMProblemSolving.L1410_PlayerNotTakingDamage {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}