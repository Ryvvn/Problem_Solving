using UnityEngine;

namespace CMProblemSolving.L1417_BulletsWrong {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}