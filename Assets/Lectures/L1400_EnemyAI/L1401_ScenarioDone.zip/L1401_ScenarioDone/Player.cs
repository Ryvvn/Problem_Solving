using UnityEngine;

namespace CMProblemSolving.L1401_ScenarioDone {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}