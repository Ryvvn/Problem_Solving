using UnityEngine;

namespace CMProblemSolving.L1418_EnemyDoesntFindPlayer {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}