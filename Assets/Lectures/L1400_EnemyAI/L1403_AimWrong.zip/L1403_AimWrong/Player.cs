using UnityEngine;

namespace CMProblemSolving.L1403_AimWrong {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}