using UnityEngine;

namespace CMProblemSolving.L1405_EnemyDoesntAttack {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}