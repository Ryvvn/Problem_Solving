using UnityEngine;

namespace CMProblemSolving.L1401_EnemyAI {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}