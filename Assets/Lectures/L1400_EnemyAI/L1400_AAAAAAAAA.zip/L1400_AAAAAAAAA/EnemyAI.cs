using UnityEngine;

namespace CMProblemSolving.L1402_AAAAAAAAA {

    public class EnemyAI : MonoBehaviour {


        private enum State {
            LookingForTarget,
            Chasing,
            Attacking,
        }


        [SerializeField] private Bullet bulletPrefab;
        [SerializeField] private Transform pistolTransform;
        [SerializeField] private Transform pistolShootPointTransform;

        private State state;
        private float moveSpeed = 1.0f;
        private float attackTimer;


        private void Awake() {
            state = State.LookingForTarget;
        }

        private void Update() {
            switch (state) {
                case State.LookingForTarget:
                    // Move left while idle
                    transform.position += Vector3.left * moveSpeed * Time.deltaTime;

                    // Is player within range?
                    float targetDistance = 3f;
                    Collider2D[] collider2DArray = Physics2D.OverlapCircleAll(transform.position, targetDistance);
                    foreach (Collider2D collider2D in collider2DArray) {
                        if (collider2D.TryGetComponent(out Player player)) {
                            // Player in range
                            state = State.Chasing;
                        }
                    }
                    break;

                case State.Chasing:
                    // Chase player
                    Vector3 moveDir = (Player.Instance.transform.position - transform.position).normalized;
                    transform.position += moveDir * moveSpeed * Time.deltaTime;

                    float distanceToPlayer = Vector3.Distance(transform.position, Player.Instance.transform.position);
                    float attackDistance = 2f;
                    if (distanceToPlayer < attackDistance) {
                        state = State.Attacking;
                    }
                    break;

                case State.Attacking:
                    // Aim Pistol at Player
                    Vector3 aimDirection = (Player.Instance.transform.position - transform.position).normalized;
                    pistolTransform.right = aimDirection;

                    attackTimer -= Time.deltaTime;
                    if (attackTimer <= 0f) {
                        float attackTimerMax = .5f;
                        attackTimer += attackTimerMax;

                        // Shoot!
                        Bullet bullet = Instantiate(bulletPrefab, pistolShootPointTransform.position, pistolShootPointTransform.rotation);
                    }
                    break;
            }
        }


    }

}