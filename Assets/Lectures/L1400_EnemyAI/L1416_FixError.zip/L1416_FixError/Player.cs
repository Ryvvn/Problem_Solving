using UnityEngine;

namespace CMProblemSolving.L1416_FixError {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            GetComponent<HealthSystem>().OnDead += Player_OnDead;
        }

        private void Player_OnDead(object sender, System.EventArgs e) {
            Destroy(gameObject);
        }

    }

}