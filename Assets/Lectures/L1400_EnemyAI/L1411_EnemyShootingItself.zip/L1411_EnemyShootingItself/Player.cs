using UnityEngine;

namespace CMProblemSolving.L1411_EnemyShootingItself {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}