using UnityEngine;

namespace CMProblemSolving.L1411_EnemyShootingItself {

    public class Bullet : MonoBehaviour {


        private void Awake() {
            Destroy(gameObject, 3f);
        }

        private void Update() {
            float moveSpeed = 5f;
            transform.position += transform.right * moveSpeed * Time.deltaTime;
        }

        private void OnTriggerEnter2D(Collider2D collider2D) {
            if (collider2D.gameObject.TryGetComponent(out HealthSystem healthSystem)) {
                healthSystem.Damage(10);
                DestroySelf();
            }
        }

        private void DestroySelf() {
            Destroy(gameObject);
        }


    }

}