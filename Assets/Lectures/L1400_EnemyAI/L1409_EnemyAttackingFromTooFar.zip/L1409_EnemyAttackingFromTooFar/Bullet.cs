using UnityEngine;

namespace CMProblemSolving.L1409_EnemyAttackingFromTooFar {

    public class Bullet : MonoBehaviour {


        private void Awake() {
            Destroy(gameObject, 3f);
        }

        private void Update() {
            float moveSpeed = 5f;
            transform.position += transform.right * moveSpeed * Time.deltaTime;
        }

        private void OnTriggerEnter2D(Collider2D collider2D) {
            if (collider2D.gameObject.TryGetComponent(out Player player)) {
                player.GetComponent<HealthSystem>().Damage(10);
                DestroySelf();
            }
        }

        private void DestroySelf() {
            Destroy(gameObject);
        }


    }

}