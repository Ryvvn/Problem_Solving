using UnityEngine;

namespace CMProblemSolving.L1409_EnemyAttackingFromTooFar {

    public class Player : MonoBehaviour {


        public static Player Instance { get; private set; }


        private void Awake() {
            Instance = this;
        }


    }

}