using UnityEngine;
using UnityEngine.InputSystem;

namespace CMProblemSolving.L1108_PlayerBarelyMoves {

    public class MovementSystem : MonoBehaviour {


        private float moveSpeed = 3f;
        private Rigidbody2D playerRigidbody2D;


        private void Awake() {
            playerRigidbody2D = GetComponent<Rigidbody2D>();
        }

        private void Update() {
            Vector2 moveDirection = Vector2.zero;

            if (Keyboard.current.aKey.wasPressedThisFrame) {
                moveDirection.x = -1f;
            }
            if (Keyboard.current.dKey.wasPressedThisFrame) {
                moveDirection.x = +1f;
            }
            if (Keyboard.current.wKey.wasPressedThisFrame) {
                moveDirection.y = +1f;
            }
            if (Keyboard.current.sKey.wasPressedThisFrame) {
                moveDirection.y = -1f;
            }

            playerRigidbody2D.linearVelocity = moveDirection * moveSpeed;
        }

    }

}