using System;
using UnityEngine;
using UnityEngine.InputSystem;

namespace CMProblemSolving.L1103_Error {

    public class MovementSystem : MonoBehaviour {


        private float moveSpeed = 3f;
        private Rigidbody2D playerRigidbody2D;


        private void Awake() {
            playerRigidbody2D = GetComponent<Rigidbody2D>();
        }

        private void Update() {
            Vector2 moveDirection = Vector2.zero;

            if (Keyboard.current.aKey.isPressed) {
                moveDirection.x = -1f;
            }
            if (Keyboard.current.dKey.isPressed) {
                moveDirection.x = +1f;
            }
            if (Keyboard.current.wKey.isPressed) {
                moveDirection.y = +1f;
            }
            if (Keyboard.current.sKey.isPressed) {
                moveDirection.y = -1f;
            }

            try {
                playerRigidbody2D.linearVelocity = moveDirection * moveSpeed;
            } catch (Exception e) {
                Debug.Log("<color=#ff0000>ERROR: " + e + "</color>");
            }
        }

    }

}