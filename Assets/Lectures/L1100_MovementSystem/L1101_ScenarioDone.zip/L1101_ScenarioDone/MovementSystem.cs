using UnityEngine;
using UnityEngine.InputSystem;

namespace CMProblemSolving.L1101_ScenarioDone {

    public class MovementSystem : MonoBehaviour {


        [SerializeField] private LayerMask wallsLayerMask;


        private float moveSpeed = 3f;
        private BoxCollider2D boxCollider2D;


        private void Awake() {
            boxCollider2D = GetComponent<BoxCollider2D>();
        }

        private void Update() {
            Vector2 moveDirection = Vector2.zero;

            if (Keyboard.current.aKey.isPressed) {
                moveDirection.x = -1f;
            }
            if (Keyboard.current.dKey.isPressed) {
                moveDirection.x = +1f;
            }
            if (Keyboard.current.wKey.isPressed) {
                moveDirection.y = +1f;
            }
            if (Keyboard.current.sKey.isPressed) {
                moveDirection.y = -1f;
            }

            if (Physics2D.BoxCast(transform.position, boxCollider2D.size, 0f, moveDirection, moveSpeed * Time.deltaTime, wallsLayerMask)) {
                // Hit a wall, don't move
            } else {
                // Didn't hit anything, move
                Vector3 moveVector = (Vector3)moveDirection * moveSpeed * Time.deltaTime;
                transform.position += moveVector;
            }
        }

    }

}