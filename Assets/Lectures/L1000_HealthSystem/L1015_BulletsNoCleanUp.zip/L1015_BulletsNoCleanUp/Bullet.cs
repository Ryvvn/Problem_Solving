using UnityEngine;

namespace CMProblemSolving.L1015_BulletsNoCleanUp {

    public class Bullet : MonoBehaviour {


        private Vector3 moveVector;


        private void Start() {
            moveVector = Vector3.right;
            moveVector.y = Random.Range(-.1f, +.1f);
        }

        private void Update() {
            float moveSpeed = 10f;
            transform.position += moveVector * moveSpeed * Time.deltaTime;
        }


    }

}