using UnityEngine;
using UnityEngine.InputSystem;

namespace CMProblemSolving.L1015_BulletsNoCleanUp {

    public class ScenarioLogic : MonoBehaviour {


        [SerializeField] private Transform bulletPrefab;
        [SerializeField] private Transform shootPoint;


        private float shootTimer;


        private void Update() {
            shootTimer -= Time.deltaTime;

            if (Mouse.current.leftButton.isPressed) {
                if (shootTimer <= 0f) {
                    float shootTimerMax = .05f;
                    shootTimer = shootTimerMax;
                    // Shoot bullet
                    Instantiate(bulletPrefab, shootPoint.position, Quaternion.identity);
                }
            }
        }


    }

}