using UnityEngine;

namespace CMProblemSolving.L1017_FixNullRef {

    public class Enemy : MonoBehaviour {

        
        private HealthSystem healthSystem;


        private void Start() {
            healthSystem = GetComponent<HealthSystem>();
        }

    }

}