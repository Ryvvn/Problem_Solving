using UnityEngine;

namespace CMProblemSolving.L1014_FastBullet {

    public class Bullet : MonoBehaviour {


        private void Awake() {
            float moveSpeed = 70f;
            GetComponent<Rigidbody2D>().linearVelocity = Vector3.right * moveSpeed;

            Destroy(gameObject, 3f);
        }

        private void OnCollisionEnter2D(Collision2D collision) {
            if (collision.gameObject.TryGetComponent(out Enemy enemy)) {
                enemy.GetComponent<HealthSystem>().Damage(5);
                DestroySelf();
            }
        }

        private void DestroySelf() {
            Destroy(gameObject);
        }


    }

}