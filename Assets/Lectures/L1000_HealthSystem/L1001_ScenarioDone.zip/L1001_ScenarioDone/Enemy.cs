using UnityEngine;

namespace CMProblemSolving.L1001_ScenarioDone {

    public class Enemy : MonoBehaviour {


    }

}