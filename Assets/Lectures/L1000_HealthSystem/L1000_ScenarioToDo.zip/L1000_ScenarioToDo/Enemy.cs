using UnityEngine;

namespace CMProblemSolving.L1000_ScenarioToDo {

    public class Enemy : MonoBehaviour {


    }

}