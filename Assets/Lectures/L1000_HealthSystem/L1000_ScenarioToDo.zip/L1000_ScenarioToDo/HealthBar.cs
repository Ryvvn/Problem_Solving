using UnityEngine;
using UnityEngine.UI;

namespace CMProblemSolving.L1000_ScenarioToDo {

    public class HealthBar : MonoBehaviour {


        [SerializeField] private Image barImage;



    }

}