using UnityEngine;
using UnityEngine.UI;

namespace CMProblemSolving.L1011_HealthBarNullRef {

    public class HealthBar : MonoBehaviour {


        [SerializeField] private HealthSystem healthSystem;
        
        
        
        private void Start() {
            healthSystem.OnHealthAmountChanged += HealthSystem_OnHealthAmountChanged;
        }

        private void HealthSystem_OnHealthAmountChanged(object sender, System.EventArgs e) {
            transform.Find("Bar").GetComponent<Image>().fillAmount = healthSystem.GetHealthAmountNormalized();
        }

    }

}