using System;
using UnityEngine;


namespace CMProblemSolving.L1006_GoingUnder0AboveMax {

    public class HealthSystem : MonoBehaviour {


        public event EventHandler OnHealthAmountChanged;
        public event EventHandler OnDead;


        [SerializeField] private int healthAmount = 100;
        [SerializeField] private int healthAmountMax = 100;


        public void Damage(int damageAmount) {
            healthAmount -= damageAmount;

            OnHealthAmountChanged?.Invoke(this, EventArgs.Empty);

            if (IsDead()) {
                OnDead?.Invoke(this, EventArgs.Empty);
            }
        }

        public void Heal(int healAmount) {
            healthAmount += healAmount;

            OnHealthAmountChanged?.Invoke(this, EventArgs.Empty);
        }

        public int GetHealthAmount() {
            return healthAmount;
        }

        public float GetHealthAmountNormalized() {
            return (float)healthAmount / healthAmountMax;
        }

        public bool IsDead() {
            return healthAmount <= 0;
        }



    }

}