using UnityEngine;
using UnityEngine.InputSystem;

namespace CMProblemSolving.L1008_HealthBarIncorrect {

    public class ScenarioLogic : MonoBehaviour {


        [SerializeField] private Transform bulletPrefab;
        [SerializeField] private Transform shootPoint;


        private void Update() {
            if (Mouse.current.leftButton.wasPressedThisFrame) {
                // Shoot bullet
                Instantiate(bulletPrefab, shootPoint.position, Quaternion.identity);
            }
        }


    }

}